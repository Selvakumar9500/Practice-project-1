package steps;

import static io.restassured.RestAssured.given;
import java.io.File;
import io.cucumber.java.en.Given;
import io.restassured.http.ContentType;

public class Githubapidemo {

	@Given("User executes Get method for github and validates the code")
	public void user_executes_get_method_and_validates_the_code() {
		   given().baseUri("https://api.github.com")
		    .basePath("/user/repos")
		    .header("Authorization","Bearer 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")
		    .when().get()
		    .then().statusCode(200);
	 
	}
	
	
	@Given("User executes Post method and User validates status code for creation")
	public void user_executes_post_method_and_user_validates_status_code_for_creation() {
	
		File file = new File("resources/data.json");
		 given().baseUri("https://api.github.com")
		    .basePath("/user/repos")
		    .header("Authorization","Bearer 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")
		    .contentType(ContentType.JSON)
			.body(file)
		    .when().post()
		    .then().statusCode(201).log().all();
		    	
	}


	@Given("User executes delete method and User validates status code for Deletion")
	public void user_provides_base_path_for_deleting_a_repo_and_authorization() {
		
		 given().baseUri("https://api.github.com/repos")
		    .basePath("/sonal04devops/APITestPostMan375")
		    .header("Authorization","Bearer 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")
		    .when().delete().then().statusCode(204).log().all();
	  
	}

	
}
