package testHTTPmethod;

import org.hamcrest.Matchers;
import org.json.JSONObject;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
public class PetStorePOSTGETRequest {
	
	// validate if the response body has your required workspace or not
	// we will make use of Hamrcrest dependency which gives us a class Matchers class
	// And methods to match expected and  actuals results
	
	@Test(priority='1')
	public void ValidatePostmanApi()
	{
		String postman_APIkey= "PMAK-65c9a41a8c53ed0001e63432-7810e3d77cb38a40dfd46997dbb8ba7ee1";
		
		RestAssured.given()
		.baseUri("https://api.postman.com")
		.basePath("/workspaces")
		.header("x-api-key",postman_APIkey)
		.when().get()
		.then().statusCode(200)
		.body("workspaces[1].name",Matchers.equalTo("ATE-phase3-PostmanTraining_Feb"),
				  "workspaces[1].id",Matchers.equalTo("1a05e8df-52f3-4306-a7ec-8134b5965dc5"),
				  "workspaces[1].visibility",Matchers.equalTo("personal"))
		
	// OR


		.body("workspaces.name",Matchers.hasItems("Phase-3lessonEndproject","ATE-phase3-PostmanTraining_Feb"),
				  "workspaces.type",Matchers.hasItems("personal")
	);
				
			
		}
			
	}