package testNGAnnotations;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(testNGAnnotations.ListenersTest.class)

     public class Home extends TestAnnotation {
	
	  @Test
	  public void clickOnCategory()
	  {
		driver.findElement(By.xpath("//div[@id='navigation']/a[1]")).click();
		System.out.println("Clicked on links");
	  }
	
}
