package antDemo;

public class AntDemo1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Executing Demo Ant");
	}
}

