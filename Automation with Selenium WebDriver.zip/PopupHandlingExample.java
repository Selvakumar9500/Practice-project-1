package selenium1;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PopupHandlingExample {
	public static void main(String[] args) {
        // Set the path to your ChromeDriver executable
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\selva\\Downloads\\New folder\\chromedriver-win64\\chromedriver.exe");

			 WebDriver driver = new ChromeDriver();
			 
  // Navigate to a webpage with a popup
			        
		driver.get("https://example.com");

  // Click on a button that triggers the popup
        driver.findElement(By.id("popupButton")).click();
        // Switch to the alert and accept it (close the popup)
        Alert alert = driver.switchTo().alert();
        alert.accept();
        // Close the browser
        driver.quit();
		
	}}