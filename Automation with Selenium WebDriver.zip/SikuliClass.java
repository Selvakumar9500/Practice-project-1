package selenium1;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

public class SikuliClass {
	public static void main(String[] args ) throws FindFailed {
		Screen s = new Screen();
		Pattern p = new Pattern("C:\\Users\\selva\\Downloads\\HelloWorld.txt.png");
		s.doubleClick(p);
	}
}

