package junitTestScripts;
import org.junit.jupiter.api.Test;
public class TestAnnotationDemo1 {
	
	// use Junit @Test annotation to exeucte your test methods
	
	@Test
	public void method1()
	{
		System.out.println("Hello Junit");
	}
}
