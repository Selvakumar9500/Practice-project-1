package phase2lessongradle;

import org.junit.jupiter.api.Test;
public class Testdemo {


	// use Junit @Test annotation to exeucte your test methods
	
	@Test
	public void method1()
	{
		System.out.println("Junit Demo Test");
	}
}
