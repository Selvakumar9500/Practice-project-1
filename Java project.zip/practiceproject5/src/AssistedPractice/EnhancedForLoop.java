package AssistedPractice;

public class EnhancedForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     
	    int arr[]={12,23,44,56,78};  
	    
	    for(int i:arr)
	    {  
	        System.out.println(i);  
	    }
	}
}