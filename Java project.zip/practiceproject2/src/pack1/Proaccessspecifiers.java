package pack1;
//3. using protected access specifiers
public class Proaccessspecifiers {

	protected void display() 
  { 
      System.out.println("This is protected access specifier"); 
  } 
}
