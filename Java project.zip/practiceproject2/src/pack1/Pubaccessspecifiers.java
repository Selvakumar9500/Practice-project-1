package pack1;
//4. using public access specifiers
public class Pubaccessspecifiers {
	public void display() 
  { 
      System.out.println("This is Public Access Specifiers"); 
  } 
}