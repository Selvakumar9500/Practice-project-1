package practiceproject7;

public class Y  extends X{
	public void methodY(){
	System.out.println("class Y method");
}
}
