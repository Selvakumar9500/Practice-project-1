package practiceproject6;

public class Dog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	   String breed;
	   int age;
	   String color;

	   void barking() {
	   }

	   void hungry() {
	   }

	   void sleeping() {
	   }
	   }
	   